﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using BackEndAccess.Models;
using BackEndAccess.Filters;

namespace BackEndAccess.Controllers
{
    [AppAuthorizationAttribute]
    public class FaqsController : Controller
    {

        public FaqsController()
        {
        }

        // GET: Faqs
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Faqs()
        {
            //using (var context = new CustomerAccessEntities()) {
            //    var result = context.Faqs.ToList();

            //    return View(result);
            //}

            return View();
        }
        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public JsonResult GetFaqs()
        {
            try
            {
                using (var context = new CustomerAccessEntities())
                {
                    var result = context.Faqs.Where(m => m.IsDeleted == false).OrderBy(m => m.Order).ThenBy(m => m.Title).ToList();
                    return Json(result, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }

        public JsonResult RemoveFaqs(string id)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        Char delimiter = ',';
                        String[] substrings = id.Split(delimiter);
                        foreach (var substring in substrings)
                        {
                            if (substring != "")
                            {
                                int intId = Int32.Parse(substring);
                                var result = context.Faqs.SingleOrDefault(f => f.Id == intId);
                                if (result != null)
                                {
                                    result.IsDeleted = true;

                                    AuditObjects obj = new AuditObjects();
                                    obj.Id = 0;
                                    obj.User = User.Identity.Name;
                                    obj.UserImpersonate = null;
                                    obj.Table = "Faqs";
                                    obj.Property = "Id";
                                    obj.LastValue = null;
                                    obj.NewValue = null;
                                    obj.FieldId = intId;
                                    obj.Action = "Remove";
                                    obj.Date = DateTime.Now;
                                    obj.Ip = Request.UserHostAddress;

                                    context.AuditObjects.Add(obj);
                                    context.SaveChanges();
                                }
                            }
                        }
                        context.SaveChanges();
                        dbContextTransaction.Commit();

                        return Json(JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }
                }
            }
        }

        [HttpPost]
        public JsonResult AddOrUpdate(Faqs faqs)
        {
            try
            {
                faqs.IsDeleted = false;
                if (faqs.Id == 0)
                {
                    return AddFaqs(faqs);
                }
                return UpdateFaqs(faqs);
            }
            catch (Exception)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }

        private JsonResult AddFaqs(Faqs faqs)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (ModelState.IsValid)
                        {
                            var result = context.Faqs.Add(faqs);
                            if (result != null)
                            {
                                AuditObjects obj = new AuditObjects();
                                obj.Id = 0;
                                obj.User = User.Identity.Name;
                                obj.UserImpersonate = null;
                                obj.Table = "Faqs";
                                obj.Property = "Id";
                                obj.LastValue = null;
                                obj.NewValue = null;
                                //obj.FieldId = form.Id;
                                obj.Action = "Add";
                                obj.Date = DateTime.Now;
                                obj.Ip = Request.UserHostAddress;

                                context.SaveChanges();
                                obj.FieldId = faqs.Id;
                                context.AuditObjects.Add(obj);
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                            }
                            ModelState.Clear();
                            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(JsonConvert.SerializeObject(ModelState.Values), JsonRequestBehavior.AllowGet);
                        }

                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }
                }
            }
        }

        private JsonResult UpdateFaqs(Faqs faqs)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (ModelState.IsValid)
                        {
                            var result = context.Faqs.SingleOrDefault(f => f.Id == faqs.Id);
                            if (result != null && !result.Equals(faqs))
                            {
                                string lastValue = "Title: " + result.Title + " / Description: " + result.Description + " / Order: " + result.Order;

                                result.Title = faqs.Title;
                                result.Description = faqs.Description;
                                result.Order = faqs.Order;

                                string newValue = "Title: " + result.Title + " / Description: " + result.Description + " / Order: " + result.Order;
                                if (lastValue != newValue)
                                {
                                    AuditObjects obj = new AuditObjects();
                                    obj.Id = 0;
                                    obj.User = User.Identity.Name;
                                    obj.UserImpersonate = null;
                                    obj.Table = "Faqs";
                                    obj.Property = "Id";
                                    obj.LastValue = lastValue;
                                    obj.NewValue = newValue;
                                    obj.FieldId = faqs.Id;
                                    obj.Action = "Update";
                                    obj.Date = DateTime.Now;
                                    obj.Ip = Request.UserHostAddress;

                                    context.AuditObjects.Add(obj);

                                    context.SaveChanges();
                                }
                                dbContextTransaction.Commit();
                            }
                            ModelState.Clear();
                            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
                        }

                        else
                        {
                            return Json(JsonConvert.SerializeObject(ModelState.Values), JsonRequestBehavior.AllowGet);
                        }

                    }
                    catch (Exception ex)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }
                }
            }
        }
    }
}