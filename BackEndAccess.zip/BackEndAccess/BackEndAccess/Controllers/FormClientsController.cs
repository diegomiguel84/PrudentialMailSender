﻿using BackEndAccess.Filters;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BackEndAccess.Controllers
{
    [AppAuthorizationAttribute]
    public class FormClientsController : Controller
    {
        // GET: Document
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult FormClients()
        {
            return View();
        }
        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public JsonResult GetFormClients()
        {
            try
            {
                using (var context = new CustomerAccessEntities())
                {
                    var result = context.FormClients.Select(m => new
                    { Id = m.Id, Name = m.Name, Descript = m.Descript, IsDeleted = m.IsDeleted }).Where(m => m.IsDeleted == false).OrderBy(m => m.Name).ToList();
                    var jsonResult = Json(result, JsonRequestBehavior.AllowGet);
                    jsonResult.MaxJsonLength = int.MaxValue;
                    return jsonResult;
                }
            }
            catch (Exception)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }

        public JsonResult RemoveFormClients(string id)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        Char delimiter = ',';
                        String[] substrings = id.Split(delimiter);
                        foreach (var substring in substrings)
                        {
                            if (substring != "")
                            {
                                int intId = Int32.Parse(substring);
                                FormClients result = context.FormClients.SingleOrDefault(f => f.Id == intId);
                                if (result != null)
                                {
                                    context.Entry(result).State = System.Data.Entity.EntityState.Modified;
                                    result.IsDeleted = true;

                                    AuditObjects obj = new AuditObjects();
                                    obj.Id = 0;
                                    obj.User = User.Identity.Name;
                                    obj.UserImpersonate = null;
                                    obj.Table = "FormClients";
                                    obj.Property = "Id";
                                    obj.LastValue = null;
                                    obj.NewValue = null;
                                    obj.FieldId = intId;
                                    obj.Action = "Remove";
                                    obj.Date = DateTime.Now;
                                    obj.Ip = Request.UserHostAddress;

                                    context.AuditObjects.Add(obj);
                                    context.SaveChanges();
                                }
                            }
                        }
                        context.SaveChanges();
                        dbContextTransaction.Commit();
                        return Json(JsonRequestBehavior.AllowGet);
                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }
                }
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult AddOrUpdate(FormClients form)
        {
            try
            {
                form.IsDeleted = false;
                if (form.Id == 0)
                {
                    return AddFormClients(form);
                }
                return UpdateFormClients(form);
            }
            catch (Exception)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }

        private byte[] fileToByteArray(HttpPostedFileBase file)
        {
            byte[] data;
            using (Stream inputStream = file.InputStream)
            {
                MemoryStream memoryStream = inputStream as MemoryStream;
                if (memoryStream == null)
                {
                    memoryStream = new MemoryStream();
                    inputStream.CopyTo(memoryStream);
                }
                data = memoryStream.ToArray();
            }
            return data;
        }

        public ActionResult byteArrayToFile(string id)
        {
            try
            {
                using (var context = new CustomerAccessEntities())
                {
                    int varId = int.Parse(id);
                    byte[] file = context.FormClients.First(m => m.Id == varId).FormFile;
                    MemoryStream pdfStream = new MemoryStream();
                    pdfStream.Write(file, 0, file.Length);
                    pdfStream.Position = 0;
                    return new FileStreamResult(pdfStream, "application/pdf");
                }
            }
            catch (Exception)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }

        private JsonResult AddFormClients(FormClients form)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (form.File == null)
                        {
                            ModelState.AddModelError("File", "El campo Archivo es obligatorio.");
                        }
                        if (ModelState.IsValid)
                        {
                            form.FormFile = this.fileToByteArray(form.File);

                            var result = context.FormClients.Add(form);
                            if (result != null)
                            {
                                AuditObjects obj = new AuditObjects();
                                obj.Id = 0;
                                obj.User = User.Identity.Name;
                                obj.UserImpersonate = null;
                                obj.Table = "FormClients";
                                obj.Property = "Id";
                                obj.LastValue = null;
                                obj.NewValue = null;
                                //obj.FieldId = form.Id;
                                obj.Action = "Add";
                                obj.Date = DateTime.Now;
                                obj.Ip = Request.UserHostAddress;

                                context.SaveChanges();
                                obj.FieldId = form.Id;
                                context.AuditObjects.Add(obj);
                                context.SaveChanges();
                                dbContextTransaction.Commit();
                            }
                            ModelState.Clear();
                            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(JsonConvert.SerializeObject(ModelState.Values), JsonRequestBehavior.AllowGet);
                        }

                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }

                }
            }
        }

        private JsonResult UpdateFormClients(FormClients form)
        {
            using (var context = new CustomerAccessEntities())
            {
                using (var dbContextTransaction = context.Database.BeginTransaction())
                {
                    try
                    {
                        if (ModelState.IsValid)
                        {

                            var result = context.FormClients.SingleOrDefault(f => f.Id == form.Id);
                            if (result != null)
                            {
                                string lastValue = "Name: " + result.Name + " / Description: " + result.Descript;

                                result.Name = form.Name;
                                result.Descript = form.Descript;

                                string newValue = "Name: " + result.Name + " / Description: " + result.Descript;
                                if (form.File != null || lastValue != newValue)
                                {
                                    if (form.File != null)
                                    {
                                        result.FormFile = this.fileToByteArray(form.File);
                                    }
                                    AuditObjects obj = new AuditObjects();
                                    obj.Id = 0;
                                    obj.User = User.Identity.Name;
                                    obj.UserImpersonate = null;
                                    obj.Table = "FormClients";
                                    obj.Property = "Id";
                                    obj.LastValue = lastValue;
                                    obj.NewValue = newValue;
                                    obj.FieldId = form.Id;
                                    obj.Action = "Update";
                                    obj.Date = DateTime.Now;
                                    obj.Ip = Request.UserHostAddress;

                                    context.AuditObjects.Add(obj);

                                    context.SaveChanges();
                                }
                                dbContextTransaction.Commit();
                            }
                            ModelState.Clear();
                            return Json(new { success = true }, JsonRequestBehavior.AllowGet);

                        }

                        else
                        {
                            return Json(JsonConvert.SerializeObject(ModelState.Values), JsonRequestBehavior.AllowGet);
                        }

                    }
                    catch (Exception)
                    {
                        dbContextTransaction.Rollback();
                        throw new ApplicationException("Ha Ocurrido un error");
                    }
                }
            }
        }
    }
}