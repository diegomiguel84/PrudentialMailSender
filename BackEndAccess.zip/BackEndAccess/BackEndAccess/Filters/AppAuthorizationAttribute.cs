﻿using BackEndAccess.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace BackEndAccess.Filters
{
    public class AppAuthorizationAttribute : FilterAttribute, IAuthorizationFilter
    {
        void IAuthorizationFilter.OnAuthorization(AuthorizationContext filterContext)
        {
            //verifica que la validación esté activada
            string enableAuth = ConfigurationManager.AppSettings["EnableADAuthorization"].ToString();
            if (enableAuth.Equals("1"))
            {
                //valida que el usuario exista en AD y pertenezca a un grupo determinado
                LdapManager ldapManager = new LdapManager();

                if (!ldapManager.CheckUser(HttpContext.Current.User.Identity.Name) ||
                   !ldapManager.IsMemberOf(HttpContext.Current.User.Identity.Name, ConfigurationManager.AppSettings["AdminGroupName"].ToString()))
                {
                    filterContext.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                    { "controller", "AccessDenied" },
                    { "action", "Index" }
                    });
                }
            }
        }
    }
   
}