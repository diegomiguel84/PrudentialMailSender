﻿CrateAppAngular();
GetBaseAddress();
var scope;

myApp.controller('CtrlFormClients', ['$scope', '$http', '$timeout', function ($scope, $http, $timeout) {
    scope = $scope;

    //TRAER ITEM/S
    $scope.ObtenerForms = function () {
        $scope.rowCollection = [];
        $scope.displayed = [].concat($scope.rowCollection);
        $scope.isLoading = true;
        $http.get(BaseAddress + "FormClients/GetFormClients").success(function (data) {

            $scope.rowCollection = [];
            $scope.displayed = [].concat($scope.rowCollection);

            $scope.rowCollection = data;
            $scope.displayed = [].concat($scope.rowCollection);
            $scope.isLoading = false;


        }).error(function () {
            $scope.isLoading = false;
            alert('Ha ocurrido un error');
        });

    }

    $scope.ObtenerForms();

    //ELIMINAR ITEM
    $scope.removeItem = function removeItem() {
        var Bajastr = "";

        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                Bajastr += value.Id + ",";
            }
        });
        if (Bajastr != "") {
            $("#confirmModal").modal("show");
        }
    }

    //CONFIRMAR BAJA
    $("#BtnConfirmaBaja").click(function () {
        $("#BtnConfirmaBaja").attr('disabled', 'disabled');
        $("#BtnCancelar").attr("disabled", "disabled");
        $("#Cargando").removeClass("hidden");
        var Bajastr = "";

        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                Bajastr += value.Id + ",";
            }
        });
        $.ajax({
            url: BaseAddress + '/FormClients/RemoveFormClients/',
            type: 'POST',
            data: { id: Bajastr },
            cache: false,
        }).success(function (result) {
            $("#confirmModal").modal("hide");
            $("#BtnConfirmaBaja").removeAttr("disabled");
            $("#BtnCancelar").removeAttr("disabled");
            $("#Cargando").addClass("hidden");
            $scope.ObtenerForms();
        }).error(function (ex) {
            $scope.isLoading = false;
            $("#BtnConfirmaBaja").removeAttr("disabled");
            $("#BtnCancelar").removeAttr("disabled");
            $("#Cargando").addClass("hidden");
            alert('Ha ocurrido un error');
        })
    })

    $("#BtnCancelar").click(function () {
        $("#confirmModal").modal("hide");
    })


    ////AGREGAR
    $scope.addItem = function addItem() {
        $("#MensajeSalidaAlta").addClass("hidden");
        $("#addFormClientsModal").modal("show");
        $("#titulo").text("Nuevo");
        $("#Name").val("");
        $("#Descript").val("");
        $("#titulo").text("Nuevo");
    }

    //CANCELAR
    $("#BtnCancelarAlta").click(function () {
        $("#addFormClientsModal").modal("hide");
        $("#Id").val(0);
        $("#Name").val("");
        $("#Descript").val("");
        $("#file").val("");
    })

    //MODIFICAR ITEM
    $scope.editItem = function editItem() {
        var selectedItems = 0;
        var item;
        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                selectedItems = selectedItems + 1;
                item = value;
            }
        });
        if (selectedItems == 1) {
            $("#MensajeSalidaAlta").addClass("hidden");
            $("#addFormClientsModal").modal("show");
            $("#titulo").text("Editar");
            $("#Id").val(item.Id);
            $("#Name").val(item.Name);
            $("#Descript").val(item.Descript);
        }
    }
    //BOTON EDITAR/ELIMINAR -- CONTROL QUE HABILITA EL/LOS BOTON/ES
    $scope.controlButton = function controlButton(action) {
        var selectedItems = 0;
        var item;
        $.each($scope.displayed, function (i, value) {
            if (value.isSelected) {
                selectedItems = selectedItems + 1;
                item = value;
            }
        });
        if (selectedItems == 1 && action == 'edit') {
            return false;
        }
        else if (selectedItems >= 1 && action == 'remove') {
            return false;
        }
        return true;
    }

    //ICONO SORT
    $scope.sort = {
        active: '',
        descending: undefined
    }

    $scope.changeSorting = function (column) {

        var sort = $scope.sort;

        if (sort.active == column) {
            sort.descending = !sort.descending;
        }
        else {
            sort.active = column;
            sort.descending = false;
        }
    };

    $scope.getIcon = function (column) {

        var sort = $scope.sort;

        if (sort.active == column) {
            return sort.descending
              ? 'fa-sort-asc'
              : 'fa-sort-desc';
        }

        return 'fa-sort';
    }

}]).directive('stRatio', function () {
    return {
        link: function (scope, element, attr) {
            var ratio = +(attr.stRatio);

            element.css('width', ratio + '%');

        }
    };
}).directive('csSelect', function () {
    return {
        require: '^stTable',
        template: '<input type="checkbox"/>',
        scope: {
            row: '=csSelect'
        },
        link: function (scope, element, attr, ctrl) {
            element.bind('change', function (evt) {
                scope.$apply(function () {
                    ctrl.select(scope.row, 'multiple');
                });
            });

            scope.$watch('row.isSelected', function (newValue, oldValue) {
                if (newValue === true) {
                    element.parent().addClass('st-selected');
                } else {
                    element.parent().removeClass('st-selected');
                }
            });
        }
    };
}).directive('pageSelect', function () {
    return {
        restrict: 'E',
        template: '<input type="text" class="select-page" ng-model="inputPage" ng-change="selectPage(inputPage)">',
        link: function (scope, element, attrs) {
            scope.$watch('currentPage', function (c) {
                scope.inputPage = c;
            });
        }
    }
})
//Busqueda
.directive('searchWatchModel', function () {
    return {
        require: '^stTable',
        scope: {
            searchWatchModel: '='
        },
        link: function (scope, ele, attr, ctrl) {
            var table = ctrl;

            scope.$watch('searchWatchModel', function (val) {
                ctrl.search(val);
            });

        }
    };
});

//aceptar y modificar
$(function () {
    $("#btnAceptar").on("click", function () {
        $("#btnAceptar").attr('disabled', 'disabled');
        $("#BtnCancelarAlta").attr("disabled", "disabled");
        $("#CargandoAlta").removeClass("hidden");
    })
});