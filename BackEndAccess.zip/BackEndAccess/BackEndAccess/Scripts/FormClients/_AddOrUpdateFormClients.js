﻿$(function () {
    $("#formPost").submit(function (event) {
        var dataString;
        event.preventDefault();
        var action = $("#formPost").attr("action");
        if ($("#formPost").attr("enctype") == "multipart/form-data") {
            //this only works in some browsers.
            //purpose? to submit files over ajax. because screw iframes.
            //also, we need to call .get(0) on the jQuery element to turn it into a regular DOM element so that FormData can use it.
            dataString = new FormData($("#formPost").get(0));
            contentType = false;
            processData = false;
        } else {
            // regular form, do your own thing if you need it
        }
        $.ajax({
            type: "POST",
            url: action,
            data: dataString,
            dataType: "json",
            contentType: contentType,
            processData: processData,
            cache: false,
            success: function (data) {
                OnSuccess(data);
            },
            error: function (data) {
                OnFailure(data);
            }
        });
    }); //end .submit()
});

function OnSuccess(response) {
    if (response.success == true) {
        $("#addFormClientsModal").modal("hide");
        $("#Id").val(0);
        $("#file").val("");
        scope.ObtenerForms();
        $("#btnAceptar").removeAttr("disabled");
        $("#BtnCancelarAlta").removeAttr("disabled");
        $("#CargandoAlta").addClass("hidden");
    }
    else {
        ModelFailure(response);
    }
}

function ModelFailure(response) {
    var msgmodel;
    $("#MensajeSalidaAlta").removeClass("hidden");
    $("#lblmensajealta ul").empty();

    msgmodel = "";
    $.each(JSON.parse(response), function (i, value) {
        $.each(value.Errors, function (e, val) {
            msgmodel += "<li>" + val.ErrorMessage + "</li>";
        });
    });
    $("#lblmensajealta ul").append(msgmodel);
    $("#btnAceptar").removeAttr("disabled");
    $("#BtnCancelarAlta").removeAttr("disabled");
    $("#CargandoAlta").addClass("hidden");
}

function OnFailure(response) {
    var msgEx;
    $("#MensajeSalidaAlta").removeClass("hidden");
    $("#lblmensajealta ul").empty();
    msgEx = "";
    msgEx += "<li>" + "Ha ocurrido un error" + "</li>";
    $("#lblmensajealta ul").append(msgEx);
    $("#btnAceptar").removeAttr("disabled");
    $("#BtnCancelarAlta").removeAttr("disabled");
    $("#CargandoAlta").addClass("hidden");
}