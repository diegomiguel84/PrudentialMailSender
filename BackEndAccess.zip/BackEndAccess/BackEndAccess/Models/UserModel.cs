﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BackEndAccess.Models
{
    public class UserModel
    {
        public static string FullName
        {
            get
            {
                return new LdapManager().GetUserFullname(HttpContext.Current.User.Identity.Name);
            }
            set { }
        }
    }
}