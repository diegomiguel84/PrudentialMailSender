﻿using eAppMailSender.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.DataAccess
{
    public class MailSenderEntities: DbContext
    {
        public MailSenderEntities()
    : base("MailSenderEntities")
        {
            this.Configuration.ProxyCreationEnabled = false;
            this.Configuration.LazyLoadingEnabled = false;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("dbo");

            base.OnModelCreating(modelBuilder);
        }

        public virtual DbSet<MailSenders> MailSenders { get; set; }
    }
}

