﻿using eAppMailSender.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.DataAccess
{
    public static class EapplicationRepository
    {
        static string connectionString =  ConfigurationManager.ConnectionStrings["EapplicationContext"].ConnectionString;
        //Obtiene la información de la solicitud en EApplication
        public static RequestInfo GetRequestInfo(string idRequest)
        {
            RequestInfo reqInfo = new RequestInfo();
            SqlConnection sqlConnection1 = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "GET_DATOS_PERSONA";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@NRO_SOLICITUD", SqlDbType.NVarChar).Value = idRequest;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                reqInfo = ParseDatabaseResponse(reader);
            }

            sqlConnection1.Close();
            return reqInfo;
        }

        private static RequestInfo ParseDatabaseResponse(SqlDataReader reader)
        {
            RequestInfo requestInfo = new RequestInfo();

            try
            {
                requestInfo.PersonType = SafeGetString(reader, "TIPO_PERSONA");
                requestInfo.TakerName = SafeGetString(reader, "NOMBRE_TOMADOR");
                requestInfo.TakerSurname = SafeGetString(reader, "APELLIDO_TOMADOR");
                requestInfo.TakerMail = SafeGetString(reader, "MAIL_TOMADOR");
                requestInfo.TakerDocumentNumber = SafeGetString(reader, "DOCUMENTO_TOMADOR");
                requestInfo.CompanyName = SafeGetString(reader, "RAZONSOCIAL");
                requestInfo.LegalRepresentativeName = SafeGetString(reader, "NOMBRE_REPRESENTANTE_LEGAL");
                requestInfo.LegalRepresentativeSurName = SafeGetString(reader, "APELLIDO_REPRESENTANTE_LEGAL");
                requestInfo.LegalRepresentativeMail = SafeGetString(reader, "MAIL_REPRESENTANTE_LEGAL");
                requestInfo.LegalRepresentativeCuit = SafeGetString(reader, "CUIT_REPRESENTANTE_LEGAL");
                requestInfo.InsuredName = SafeGetString(reader, "NOMBRE_ASEGURADO");
                requestInfo.InsuredMail = SafeGetString(reader, "MAIL_ASEGURADO");
                requestInfo.InsuredSurname = SafeGetString(reader, "APELLIDO_ASEGURADO");
                requestInfo.LpCode = SafeGetString(reader, "LP_CODE");
                requestInfo.LpName = SafeGetString(reader, "NOMBRE_LP");
                requestInfo.LpMail = SafeGetString(reader, "MAIL_LP");
                requestInfo.Dni = SafeGetString(reader, "DNI");
                requestInfo.Cuit = SafeGetString(reader, "CUIT");
            }
            catch (Exception Ex)
            {

            }

            return requestInfo;
        }
        private static string SafeGetString(this SqlDataReader reader, string colName)
        {
            if (reader[colName] != null && reader[colName] != DBNull.Value)
                return reader[colName].ToString();

            return string.Empty;
        }



    }

}
