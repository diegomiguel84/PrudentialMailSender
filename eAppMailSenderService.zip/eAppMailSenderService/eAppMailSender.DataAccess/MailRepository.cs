﻿using eAppMailSender.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.DataAccess
{
    public class MailRepository
    {
        public void AddMailObject(MailLogger email)
        {
            MailSenders sender = new MailSenders();
            sender.NOMBRE_TOMADOR = email.TakerName;
            sender.APELLIDO_TOMADOR = email.TakerSurname;
            sender.MAIL_TOMADOR = email.TakerMail;
            sender.MAIL_ASEGURADO = email.InsuredMail;
            sender.NOMBRE_ASEGURADO = email.InsuredName;
            sender.APELLIDO_ASEGURADO = email.InsuredSurname;
            sender.NOMBRE_LP = email.LpName;
            sender.MAIL_LP = email.LpMail;
            sender.ID_SOLICITUD = email.IdRequest;
            sender.ATTACHEMENT = email.Attachment;
            sender.NOMBRE_ARCHIVO = email.FileName;
            sender.FECHA_CREACION = email.CreateDate;

            if (email.SentDate.Equals(DateTime.MinValue))
            {
                sender.FECHA_ENVIO = null;
            }
            else
            {
                sender.FECHA_ENVIO = email.SentDate;
            }
            sender.ENVIADO = email.Sent;
            sender.MOTIVO = email.Reason;
            sender.TIPO_DESTINATARIO = email.DestType;

            AddMailObject(sender);
        }

        private void AddMailObject(MailSenders email)
        {
            using (MailSenderEntities context = new MailSenderEntities())
            {
                context.MailSenders.Add(email);
                context.SaveChanges();
            }
        }

        /// <summary>
        /// Retorna verdadero si la solicitud fue enviada por mail para un tipo de destinatario
        /// </summary>
        /// <param name="idRequest"></param>
        /// <param name="desType"></param>
        /// <returns></returns>
        public bool RequestWasSent(string idRequest, string desType)
        {
            using (MailSenderEntities context = new MailSenderEntities())
            {
                return context.MailSenders.FirstOrDefault(m => m.ID_SOLICITUD == idRequest && m.TIPO_DESTINATARIO == desType &&
                    m.ENVIADO == true) != null;

            }
        }

    }
}
