﻿using eAppMailSender.DataAccess;
using eAppMailSender.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Bussiness
{
    public class FileManager
    {
        static string SrcFolder = ConfigurationManager.AppSettings["SrcFolder"];
        static string DestFolder = ConfigurationManager.AppSettings["DestFolder"];
        static string ErrorFolder = ConfigurationManager.AppSettings["ErrorFolder"];
        MailSender _sender = new MailSender();
        MailRepository _repository = new MailRepository();

        public void ProcessFiles()
        {
            //Obtiene todos los archivos de un directorio
            DirectoryInfo di = new DirectoryInfo(SrcFolder);
            FileInfo[] files = di.GetFiles("*.pdf");

            foreach(FileInfo file in files)
            {
                MailLogger logger = new MailLogger();
                logger.FileName = file.Name;
                try
                {
                    Console.WriteLine("Procesando solicitud " + file.Name);
                    AuditLog.LogText(DateTime.Now.ToString());
                    AuditLog.LogText("Nombre de archivo:" + file.Name);
                    if (ParseFileName(file.Name))
                    {
                        logger.IdRequest = GetRequestId(file.Name);
                        //Obtengo la información de la solicitud
                        RequestInfo request =EApplicationRequest.GetRequestInfo(GetRequestId(file.Name));
                        if(ValidateRequestData(request))
                        {
                            MailResponse insuredResponse = new MailResponse();
                            MailResponse takerResponse = new MailResponse();
                            //Envía mail al asegurado
                            if(!string.IsNullOrEmpty(request.InsuredMail))
                            {
                                insuredResponse = SendMailByType(request, file, logger, MailSenders.TYPE_ASEGURADO);
                            }

                            //Envía mail al tomador si difiere del asegurado
                            if (request.PersonType.Equals(PersonTypeExtension.ToString(PersonTypeEnum.FISICA)))
                            {
                                //si es una persona física se compara contra el tomador
                                if (!string.IsNullOrEmpty(request.TakerMail) && !request.TakerMail.Equals(request.InsuredMail))
                                {
                                    takerResponse = SendMailByType(request, file, logger, MailSenders.TYPE_TOMADOR);
                                }
                            }
                            else
                            {
                                //se compara contra el representante legal
                                if (!string.IsNullOrEmpty(request.LegalRepresentativeMail) && !request.TakerMail.Equals(request.InsuredMail))
                                {
                                    takerResponse = SendMailByType(request, file, logger, MailSenders.TYPE_TOMADOR);
                                }
                            }
                               

                            if (!insuredResponse.HasError && !takerResponse.HasError)
                            {
                                MoveFile(file.FullName, DestFolder + "\\" + file.Name);
                            }
                            else
                            {
                                MoveFile(file.FullName, ErrorFolder + "\\" + file.Name);
                            }

                        }
                        else
                        {
                            MoveFile(file.FullName, ErrorFolder + "\\" + file.Name);
                            LogErrorMail(logger, AppResources.ERROR_RECIPIENTS);
                        }
                    }
                    else
                    {
                        MoveFile(file.FullName, ErrorFolder + "\\" + file.Name);
                        LogErrorMail(logger, AppResources.ERROR_FILE_NAME_FORMAT);
                    }
                }
                catch(Exception ex)
                {
                    MoveFile(file.FullName, ErrorFolder + "\\" + file.Name);
                    LogErrorMail(logger, ex.Message);
                    AuditLog.LogText("Error: " + ex.Message);
                }
            }
        }

        private MailResponse SendMailByType(RequestInfo request, FileInfo file, MailLogger logger, string typeDest)
        {
            MailResponse response = new MailResponse();
            MailRepository repo = new MailRepository();

            //Envia el mail
            byte[] attachment = System.IO.File.ReadAllBytes(file.FullName);
            logger.Attachment = attachment;
            logger.DestType = typeDest;
            request.FillMailLogger(logger);
            if (!repo.RequestWasSent(logger.IdRequest, typeDest))
            {
                response = _sender.SendMail(request, attachment, file.Name, typeDest);

                if (!response.HasError)
                {
                    LogSuccessMail(logger);
                }
                else
                {
                    LogErrorMail(logger, AppResources.ERROR_MAIL_NOT_SENT);
                }
            }
            else
            {
                //la solicitud ya fue enviada al tomador o destinatario
                response.HasError = false;
                LogErrorMail(logger, AppResources.ERROR_REQUEST_SENT);
            }

            return response;
        }

        //Valida que el nombre del archivo tenga formato correcto
        private bool ParseFileName(string fileName)
        {
            try
            {
                if (!string.IsNullOrEmpty(fileName))
                {
                    string[] partsName = fileName.Split('-');
                    if(partsName.Length == 3)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        private string GetRequestId(string fileName)
        {
            return fileName.Split('-')[0];
        }

        //Valida los datos del request. Si el tipo de persona es Física valida que exista el mail del asegurado o del tomador
        //Si el tipo de persona es jurídica valida que exista el mail del representante legal
        private bool ValidateRequestData(RequestInfo request)
        {
            if ((string.IsNullOrEmpty(request.InsuredMail) && string.IsNullOrEmpty(request.TakerMail) 
                && request.PersonType.Equals(PersonTypeExtension.ToString(PersonTypeEnum.FISICA)))
               || (string.IsNullOrEmpty(request.LegalRepresentativeMail) && 
                    request.PersonType.Equals(PersonTypeExtension.ToString(PersonTypeEnum.JURIDICA))))
            {
                return false;
            }

            return true;
        }

        private void MoveFile(string src, string dest)
        {
            try
            {
                if(System.IO.File.Exists(dest))
                {
                    System.IO.File.Delete(dest);
                }
                System.IO.File.Move(src, dest);
            }
            catch(Exception ex)
            {
                AuditLog.LogText("Error: " + ex.Message);
            }
        }

        private void LogSuccessMail(MailLogger logger)
        {
            logger.Reason = AppResources.OK;
            logger.Sent = true;
            logger.SentDate = DateTime.Now;
            _repository.AddMailObject(logger);
        }

        private void LogErrorMail(MailLogger logger, string reason)
        {
            logger.Reason = reason;
            logger.Sent = false;
            _repository.AddMailObject(logger);
        }
    }
}
