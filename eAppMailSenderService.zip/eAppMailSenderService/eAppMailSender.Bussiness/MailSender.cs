﻿using eAppMailSender.DataAccess;
using eAppMailSender.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Bussiness
{
    public class MailSender
    {
       
        static string app_mailServiceBaseUrl = ConfigurationManager.AppSettings["Mail-ServiceBaseUrl"];
        static string app_mailSendOnlyTo = ConfigurationManager.AppSettings["Mail-SendOnlyTo"];
        static string app_mailFrom = ConfigurationManager.AppSettings["Mail-From"];
        static string app_mailFromAlias = ConfigurationManager.AppSettings["Mail-From-Alias"];
        static string app_MailSubject = ConfigurationManager.AppSettings["Mail-Subject"];
        static string app_SmtpServer = ConfigurationManager.AppSettings["SMTPServer"];
        static string app_SmtpPort = ConfigurationManager.AppSettings["SMTPPort"];
        static string app_SmtpUser = ConfigurationManager.AppSettings["SMTPUser"];
        static string app_SmtpPassword = ConfigurationManager.AppSettings["SMTPPassword"];
        static string app_SrcFolder = ConfigurationManager.AppSettings["SrcFolder"];
        static string app_TempFolder = ConfigurationManager.AppSettings["TempFolder"];
        static string app_GoogleAnalyticsKey = ConfigurationManager.AppSettings["GoogleAnalyticsKey"];
        static string app_MailHeader = ConfigurationManager.AppSettings["MailHeaderImage"];
        static string app_MailFooter = ConfigurationManager.AppSettings["MailFooterImage"];
        static string app_MailSign = ConfigurationManager.AppSettings["MailSign"];
        static string app_IsTesting = ConfigurationManager.AppSettings["IsTesting"];
        static string app_MailTesting = ConfigurationManager.AppSettings["MailTesting"];
        static string app_Enviroment = ConfigurationManager.AppSettings["Enviroment"];


        public class Mail
        {
            public string To { get; set; }
            public string Subject { get; set; }
            public string Cc { get; set; }
            public string Msg { get; set; }
            public string App { get; set; }
            public string From { get; set; }
            public bool? Html { get; set; }
            public byte[] Attachment { get; set; }
            public string AttachmentName { get; set; }
            public string Password { get; set; }
            public string Identifier { get; set; }
        }

        public MailResponse SendMail(RequestInfo request, byte[] attachment, string attachmentName, string tipoDestinatario)
        {
            MailResponse response = new MailResponse();
            try
            {
                Mail email = new Mail();

                if (tipoDestinatario.Equals(MailSenders.TYPE_ASEGURADO))
                {
                    email.To = request.InsuredMail;
                    email.Password = request.Dni.Trim().Replace(".", "");
                }
                else
                {
                    if (request.PersonType.Equals(PersonTypeExtension.ToString(PersonTypeEnum.FISICA)))
                    {
                        email.To = request.TakerMail;
                        email.Password = request.TakerDocumentNumber.Trim().Replace(".", "");
                    }
                    else
                    {
                        email.To = request.LegalRepresentativeMail;
                        email.Password = request.LegalRepresentativeCuit.Trim().Replace("-", "");
                    }
                }

                response = SendMail(request, attachment, attachmentName, email);

            }
            catch (Exception ex)
            {
                AuditLog.LogText("Error: " + ex.Message);
                response.HasError = true;
                response.Message = AppResources.ERROR_MAIL_NOT_SENT;
            }
            return response;
        }

        public MailResponse SendMail(RequestInfo request, byte[] attachment, string attachmentName, Mail email)
        {
            MailResponse response = new MailResponse();
            try
            {
                string destination = string.Empty;

                //setea cc
                if(!string.IsNullOrEmpty(request.LpMail))
                {
                    email.Cc = request.LpMail;
                }
                email.Identifier = email.To;
                email.Attachment = attachment;
                email.AttachmentName = attachmentName;
                email.Subject = app_MailSubject;

                bool sent = SendMail(email);
                if(sent)
                {
                    response.HasError = false;
                    response.Message = AppResources.OK;
                }
                else
                {
                    response.HasError = true;
                    response.Message = AppResources.ERROR_MAIL_NOT_SENT;
                }
                return response;
            }
            catch(Exception ex)
            {
                AuditLog.LogText("Error: " + ex.Message);
                response.HasError = true;
                response.Message = AppResources.ERROR_MAIL_NOT_SENT;
                return response;
            }
        }

        //Envía el mail via smtp
        private bool SendMail(Mail mail)
        {
            try
            {
                var client = new SmtpClient(app_SmtpServer, int.Parse(app_SmtpPort));
                if(app_Enviroment != null)
                {
                    client.Credentials = new NetworkCredential(app_SmtpUser, app_SmtpPassword);
                    client.EnableSsl = true;
                };

                if (app_IsTesting.Equals("1"))
                {
                    mail.To = app_MailTesting;
                    mail.Cc = app_MailTesting;
                }

                MailAddress fromAddress = new MailAddress(app_mailFrom, app_mailFromAlias);
                MailAddress ToAddress = new MailAddress(mail.To, mail.To);
                MailMessage mailMessage = new MailMessage(fromAddress, ToAddress);
                mailMessage.Subject = mail.Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = ConfigBody(mail.Identifier, mailMessage);
                mailMessage.CC.Add(new MailAddress(mail.Cc, mail.Cc));
                byte[] srcFile = mail.Attachment;
                System.Net.Mime.ContentType contentType = new System.Net.Mime.ContentType();
                contentType.MediaType = System.Net.Mime.MediaTypeNames.Application.Octet;
                contentType.Name = mail.AttachmentName;

                //
                string resultPath = EncryptPdf.Encript(srcFile, mail.Password);

                mailMessage.Attachments.Add(new Attachment(app_TempFolder + "\\" + resultPath, contentType));

                
                client.Send(mailMessage);
               
                return true;
            }
            catch (Exception ex)
            {
                AuditLog.LogText("Error:" + ex.Message);
                return false;
            }
        }

        private string ConfigBody(string identifier, MailMessage mailMessage)
        {
            string body = AppResources.EMAIL_TEXT;
            var inlineHeader = new Attachment("Assets/header.png");
            inlineHeader.ContentId = Guid.NewGuid().ToString();
            inlineHeader.ContentDisposition.Inline = true;
            inlineHeader.ContentDisposition.DispositionType = DispositionTypeNames.Inline;

            var inlineSign = new Attachment("Assets/firma.png");
            inlineSign.ContentId = Guid.NewGuid().ToString();
            inlineSign.ContentDisposition.Inline = true;
            inlineSign.ContentDisposition.DispositionType = DispositionTypeNames.Inline;

            var inlineFooter = new Attachment("Assets/footer.png");
            inlineFooter.ContentId = Guid.NewGuid().ToString();
            inlineFooter.ContentDisposition.Inline = true;
            inlineFooter.ContentDisposition.DispositionType = DispositionTypeNames.Inline;

            mailMessage.Attachments.Add(inlineHeader);
            mailMessage.Attachments.Add(inlineSign);
            mailMessage.Attachments.Add(inlineFooter);

            body = body.Replace("@@header", inlineHeader.ContentId)
                .Replace("@@footer", inlineFooter.ContentId)
                .Replace("@@sign", inlineSign.ContentId)
                .Replace("@@cid", identifier)
                .Replace("@@tid", app_GoogleAnalyticsKey)
                .Replace("@@el", "Recepción de email");

            return body;
        }

    }
}
