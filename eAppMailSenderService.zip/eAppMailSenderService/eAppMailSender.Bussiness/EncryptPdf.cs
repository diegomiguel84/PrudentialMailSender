﻿using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Bussiness
{
    public class EncryptPdf
    {
        static string TempFolder = ConfigurationManager.AppSettings["TempFolder"];
        public static string Encript(byte[] originalFile, string password)
        {
            //Stream stream = new MemoryStream(byteArray);
            PdfReader reader = new PdfReader(originalFile);
            string tempName = string.Format("encriptedDoc_{0}.pdf", DateTime.Now.ToString("ddMMyyyyhhmmss"));
            using (FileStream file = new FileStream(TempFolder + "\\" + tempName, FileMode.Create, FileAccess.Write))
            {
                using (PdfStamper stamper = new PdfStamper(reader, file))
                {
                    stamper.SetEncryption(
                        Encoding.ASCII.GetBytes("Prudential"),
                        Encoding.ASCII.GetBytes(password),
                        PdfWriter.ALLOW_PRINTING,
                        PdfWriter.ENCRYPTION_AES_128);
  
                }
            }

            //retorna el nombre del pdf encriptado
            reader.Close();
            return tempName;
        }

    }
}
