﻿using eAppMailSender.DataAccess;
using eAppMailSender.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Bussiness
{
    public class EApplicationRequest
    {
        public static RequestInfo GetRequestInfo(string idRequest)
        {
            return EapplicationRepository.GetRequestInfo(idRequest);
        }


    }
}
