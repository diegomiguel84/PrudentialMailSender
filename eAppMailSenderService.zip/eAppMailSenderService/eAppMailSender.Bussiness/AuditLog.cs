﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Bussiness
{
    public class AuditLog
    {
        public static void LogText(string text)
        {
            // Create a writer and open the file:
            StreamWriter log;

            if (!File.Exists("logfile.txt"))
            {
                log = new StreamWriter("logfile.txt");
            }
            else
            {
                log = File.AppendText("logfile.txt");
            }

            // Write to the file:
            log.WriteLine(text);
            log.WriteLine();

            // Close the stream:
            log.Close();
        }

        public static void LogSeparator()
        {
            LogText("*****************************************************************************************************");
        }
    }
}
