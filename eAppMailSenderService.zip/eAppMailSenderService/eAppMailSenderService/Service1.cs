﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using eAppMailSender.Bussiness;

namespace eAppMailSenderService
{
    public partial class Service1 : ServiceBase
    {
        private EventLog eventLog;
        private string SrcFolder = ConfigurationManager.AppSettings["SrcFolder"];
        private string DestFolder = ConfigurationManager.AppSettings["DestFolder"];
        private string ErrFolder = ConfigurationManager.AppSettings["ErrFolder"];
        private string FindFile = ConfigurationManager.AppSettings["FindFile"];

        public Service1()
        {
            InitializeComponent();
            /*if (!EventLog.SourceExists("MailSenderService"))
            {
                EventLog.CreateEventSource("MailSenderService", "MailSenderLog");
            }
            eventLog.Source = "MailSenderService";
            eventLog.Log = "MailSenderLog";*/
        }

        protected override void OnStart(string[] args)
        {
           // eventLog.WriteEntry("El servicio inició correctamente");
            
        }

        protected override void OnStop()
        {
            eventLog.WriteEntry("El servicio finalizó correctamente");
        }

        private void FindSourceFiles()
        {
            foreach (var item in Directory.GetFiles(SrcFolder, "*.pdf", SearchOption.TopDirectoryOnly))
            {

            }  
        }


    }
}
