﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Model
{
    public class RequestInfo
    {
        public string PersonType { get; set; }
        public string TakerName { get; set; }
        public string TakerSurname { get; set; }
        public string TakerMail { get; set; }
        public string TakerDocumentNumber { get; set; }
        public string CompanyName { get; set; }
        public string LegalRepresentativeName { get; set; }
        public string LegalRepresentativeSurName { get; set; }
        public string LegalRepresentativeMail { get; set; }
        public string LegalRepresentativeCuit { get; set; }
        public string InsuredName { get; set; }
        public string InsuredSurname { get; set; }
        public string InsuredMail { get; set; }
        public string LpCode { get; set; }
        public string LpName { get; set; }
        public string LpMail { get; set; }
        public string Dni { get; set; }
        public string Cuit { get; set; }

        public void FillMailLogger(MailLogger logger)
        {

            if (PersonType.Equals(PersonTypeExtension.ToString(PersonTypeEnum.FISICA)))
            {
                logger.TakerName = TakerName;
                logger.TakerSurname = TakerSurname;
                logger.TakerMail = TakerMail;
            }
            else
            {
                logger.TakerName = LegalRepresentativeName;
                logger.TakerSurname = LegalRepresentativeSurName;
                logger.TakerMail = LegalRepresentativeMail;
            }

            logger.InsuredName = InsuredName;
            logger.InsuredSurname = InsuredSurname;
            logger.InsuredMail = InsuredMail;

            logger.LpName = LpName;
            logger.LpMail = LpMail;

         
        }


    }
}
