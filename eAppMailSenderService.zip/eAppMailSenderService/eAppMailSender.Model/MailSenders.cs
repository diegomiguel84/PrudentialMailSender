﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Model
{
    public class MailSenders
    {
        public static string TYPE_ASEGURADO = "ASEGURADO";
        public static string TYPE_TOMADOR = "TOMADOR";

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long ID_NOTIFICACION { get; set; }
        public string ID_SOLICITUD { get; set; }
        public string NOMBRE_TOMADOR { get; set; }
        public string APELLIDO_TOMADOR { get; set; }
        public string MAIL_TOMADOR { get; set; }
        public string NOMBRE_ASEGURADO { get; set; }
        public string APELLIDO_ASEGURADO { get; set; }
        public string MAIL_ASEGURADO { get; set; }
        public string NOMBRE_LP { get; set; }
        public string APELLIDO_LP { get; set; }
        public string MAIL_LP { get; set; }
        public byte[] ATTACHEMENT { get; set; }
        public string NOMBRE_ARCHIVO { get; set; }
        public DateTime? FECHA_CREACION { get; set; }
        public DateTime? FECHA_ENVIO { get; set; }
        public string DESTINATARIOS { get; set; }
        public bool? ENVIADO { get; set; }
        public string MOTIVO { get; set; }

        public string TIPO_DESTINATARIO { get; set; }


        [NotMapped]
        public string ASEGURADO { get { return NOMBRE_ASEGURADO + ' ' + APELLIDO_ASEGURADO; } }
        [NotMapped]
        public string TOMADOR { get { return NOMBRE_TOMADOR + ' ' + APELLIDO_TOMADOR; } }
        [NotMapped]
        public string LP { get { return NOMBRE_LP + ' ' + APELLIDO_LP; } }
    }
}
