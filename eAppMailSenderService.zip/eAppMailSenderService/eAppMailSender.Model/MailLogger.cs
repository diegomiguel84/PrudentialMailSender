﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Model
{
    public class MailLogger
    {
        public string IdRequest { get; set; }
        public string TakerName { get; set; }
        public string TakerSurname { get; set; }
        public string TakerMail { get; set; }
        public string InsuredName { get; set; }
        public string InsuredSurname { get; set; }
        public string InsuredMail { get; set; }
        public string LpName { get; set; }
        public string LpMail { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime SentDate { get; set; }
        public bool Sent { get; set; }
        public string Reason { get; set; }
        public byte[] Attachment { get; set; }
        public string FileName { get; set; }
        public string DestType { get; set; }


        public MailLogger()
        {
            CreateDate = DateTime.Now;
        }

    }
}
