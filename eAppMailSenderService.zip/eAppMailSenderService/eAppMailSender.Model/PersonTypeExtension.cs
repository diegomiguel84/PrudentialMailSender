﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eAppMailSender.Model
{
    public class PersonTypeExtension
    {

        public static string ToString(PersonTypeEnum me)
        {
            switch (me)
            {
                case PersonTypeEnum.FISICA:
                    return "Física";
                case PersonTypeEnum.JURIDICA:
                    return "Jurídica";
                default:
                    return string.Empty;
            }
        }

    }
}
