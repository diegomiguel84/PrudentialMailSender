﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;

namespace MailSender.Models
{
    public class LdapManager
    {
        public string RemoveDomain(string user)
        {
            int index = user.IndexOf("\\");
            user = index > -1 ? user.Substring(index + 1) : user;

            return user;
        }
        public bool CheckUser(string user)
        {
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["Dominio"].ToString()))
            {
                user = RemoveDomain(user);
                return
                    //chequea que el usuario exista, en algunas configuraciones de dominio si el usuario no existe lo loguea como GUEST con cualquier password.
                    UserPrincipal.FindByIdentity(pc, user) != null;
            };

        }

        public string GetUserFullname(string user)
        {
            user = RemoveDomain(user);
            string fullname = string.Empty;
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["Dominio"].ToString()))
            {
                var userAD = UserPrincipal.FindByIdentity(pc, user);
                if (userAD != null)
                {
                    fullname = userAD.DisplayName;
                }

            };
            return fullname;
        }

        public IEnumerable<string> GetGroups(string userName)
        {
            var groups = new List<string>();

            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["Dominio"].ToString()))
            {
                var user = UserPrincipal.FindByIdentity(pc, userName);
                if (user != null)
                {
                    groups = user.GetGroups().Where(g => g is GroupPrincipal).Select(g => g.Name).ToList();
                }
            };

            return groups;
        }

        public bool IsMemberOf(string userName, string groupName)
        {
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["Dominio"].ToString()))
            {
                var user = UserPrincipal.FindByIdentity(pc, userName);
                if (user != null)
                {
                    return user.GetGroups().Any(g => g is GroupPrincipal && g.Name == groupName);
                }
            }
            return false;
        }

        public IEnumerable<string> GetAllMembersOf(string groupName)
        {
            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationManager.AppSettings["Dominio"].ToString()))
            {
                GroupPrincipal group = GroupPrincipal.FindByIdentity(pc, groupName);
                if (group != null)
                {
                    return group.GetMembers().Select(m => m.SamAccountName).ToList();
                }
            }
            return new List<string>();
        }

    }
}