﻿using eAppMailSender.DataAccess;
using eAppMailSender.Model;
using MailSender.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MailSender.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (new LdapManager().IsMemberOf(HttpContext.User.Identity.Name,
                ConfigurationManager.AppSettings["AdminGroupName"].ToString()))
            {
                return View();
            }
            else
            {
                return View("Error");
            }
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "None")]
        public JsonResult GetMailSender(string solicitud, string tomador, string desde, string hasta, bool enviado, string lp)
        {
            var result = new List<MailSenders>();
            IQueryable<MailSenders> query;

            DateTime fechaDesde = DateTime.MinValue;
            DateTime fechaHasta = DateTime.MinValue;
            if (!string.IsNullOrEmpty(desde))
            {
                DateTime.TryParseExact(desde, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out fechaDesde);
            }

            if (!string.IsNullOrEmpty(hasta))
            {
                bool success = DateTime.TryParseExact(hasta, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out fechaHasta);
                if(success)
                {
                    fechaHasta = fechaHasta.AddHours(23).AddMinutes(59);
                }
            }

            using (var context = new MailSenderEntities())
            {
                query = context.MailSenders.AsNoTracking();

                if (!string.IsNullOrEmpty(solicitud))
                    query = from ml in query
                            where ml.ID_SOLICITUD.TrimEnd().ToUpper().Contains(solicitud.TrimEnd().ToUpper())
                            select ml;

                if (!string.IsNullOrEmpty(tomador))
                    query = from ml in query
                            where ml.NOMBRE_TOMADOR.TrimEnd().Contains(tomador.TrimEnd().ToUpper()) ||
                            ml.APELLIDO_TOMADOR.TrimEnd().Contains(tomador.TrimEnd().ToUpper())
                            select ml;

                if (!string.IsNullOrEmpty(desde))
                    query = from ml in query
                            where ml.FECHA_CREACION >= fechaDesde
                            select ml;

                if (!string.IsNullOrEmpty(hasta))
                    query = from ml in query
                            where ml.FECHA_CREACION <= fechaHasta
                            select ml;

                if (enviado)
                    query = from ml in query
                            where ml.ENVIADO == enviado
                            select ml;

                if (!string.IsNullOrEmpty(lp))
                    query = from ml in query
                            where ml.NOMBRE_LP.TrimEnd().Contains(lp.TrimEnd().ToUpper()) ||
                            ml.APELLIDO_LP.TrimEnd().Contains(lp.TrimEnd().ToUpper())
                            select ml;

                if(!fechaDesde.Equals(DateTime.MinValue) && !fechaHasta.Equals(DateTime.MinValue) && fechaHasta < fechaDesde)
                {
                    return  Json(new { success = false, responseText = "La fecha Desde debe ser menor a la fecha Hasta" }, JsonRequestBehavior.AllowGet);
                }
                result = query.OrderByDescending(m => m.FECHA_ENVIO).ToList();
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult byteArrayToFile(long id)
        {
            try
            {
                using (var context = new MailSenderEntities())
                {
                    var attachement = context.MailSenders.FirstOrDefault(m => m.ID_NOTIFICACION == id);
                    if (attachement != null)
                    {
                        byte[] file = attachement.ATTACHEMENT;
                        MemoryStream pdfStream = new MemoryStream();
                        pdfStream.Write(file, 0, file.Length);
                        pdfStream.Position = 0;
                        return new FileStreamResult(pdfStream, "application/pdf");
                    }
                    else
                        return null;
                }
            }
            catch (Exception)
            {
                throw new ApplicationException("Ha Ocurrido un error");
            }
        }
    }
}